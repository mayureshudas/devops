DECLARE    
v_error VARCHAR2(4000);
v_retcode VARCHAR2(10);
BEGIN
XX_CREATE_ITEM.XX_CREATEITEM (v_error,v_retcode);
END;
/
