/********************************************************
***  Script to sequence table
***
**********************************************************/
DROP SEQUENCE XX_JENKINS_TEST_SEQ
/


CREATE SEQUENCE XX_JENKINS_TEST_SEQ
START WITH     2000
INCREMENT BY   1
NOCACHE
NOCYCLE
/
